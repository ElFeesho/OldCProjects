#include <gtk/gtk.h>
#include "errors.h"
#include "database.h"
#include "browser.h"
#include "misc.h"
#include "levels.h"
#include "stopic.h"
#include "globals.h"
#include "stopic.h"
#include "board.h"

/* Callback Protostopic */
static void stopic_button_click(GtkWidget *button, gpointer selected);
/* End of protostopic */

struct stopic_node *stopic_list = NULL;
struct stopic_node *stopic_selected = NULL;

static int stopic_count = 0;

int stopic_load_list()
{
	sqlite3_stmt *stopic = database_query(g_strdup_printf("SELECT * FROM sub_topics INNER JOIN Topic_Subs ON sub_topics.Subtopic_ID = Topic_Subs.stopic_id WHERE Topic_Subs.topic_id = %d",topics_selected->id));
	int count = 0;
	while(sqlite3_step(stopic)==SQLITE_ROW)
	{
		if(stopic_list == NULL)
		{
			stopic_list = malloc(sizeof(struct stopic_node));
			stopic_list->name = g_strdup_printf("%s",sqlite3_column_text(stopic,1));;
			
			stopic_list->id = sqlite3_column_int(stopic,0);
			//strcpy(stopic_list->name, (char*)sqlite3_column_text(stopic,1));
			stopic_list->next = NULL;
		}
		else
		{
			struct stopic_node *temp = malloc(sizeof(struct stopic_node));
			temp->name = g_malloc0(64);
			
			temp->id = sqlite3_column_int(stopic,0);
			strcpy(temp->name, (char*)sqlite3_column_text(stopic,1));
			temp->next = stopic_list;
			stopic_list = temp;
		}
		count++;
	}
	stopic_count = count;
	return count;	
}

void stopic_create_table()
{
	if(!stopic_list)
	{
		stopic_load_list();
		if(!stopic_count)
		{
			error_dialog("Failed to load question stopic!");
			exit(0);
		}
	}	
	if(browser_table == NULL)
		browser_table = gtk_table_new(8,8,1);
	else
		gtk_table_resize(GTK_TABLE(browser_table),8,8);
	
	gtk_table_set_homogeneous(GTK_TABLE(browser_table),0);
	
	GtkWidget *stopic[4];
	struct stopic_node *temp = stopic_list;
	int i = 0;
	while(temp)
	{
		stopic[i] = gtk_button_new_with_label(temp->name); 
		g_signal_connect(G_OBJECT(stopic[i++]),"clicked",G_CALLBACK(stopic_button_click),temp);
		temp = temp->next;
	}
	browser_change_label(misc_create_banner("Select a Question Type",50));
	
	gtk_table_attach(GTK_TABLE(browser_table),gtk_label_new("The question type affects which questions you are given."),0,8,1,2,GTK_FILL,GTK_FILL,0,0);
	gtk_table_attach(GTK_TABLE(browser_table),stopic[0],2,3,3,4,GTK_FILL,GTK_FILL,0,0);
	gtk_table_attach(GTK_TABLE(browser_table),stopic[1],2,3,5,6,GTK_FILL,GTK_FILL,0,0);
	gtk_table_attach(GTK_TABLE(browser_table),stopic[2],5,6,3,4,GTK_FILL,GTK_FILL,0,0);
	gtk_table_attach(GTK_TABLE(browser_table),stopic[3],5,6,5,6,GTK_FILL,GTK_FILL,0,0);
	
	
	gtk_widget_show_all(browser_table);
	return;
}

void stopic_button_click(GtkWidget *button, gpointer selected)
{
	stopic_selected = selected;
	gtk_container_forall(GTK_CONTAINER(browser_table),(GtkCallback)gtk_widget_destroy,NULL);
	board_create_table();
	browser_add_history(gtk_button_new_with_label("Sub Topic"),stopic_create_table);
}
