#ifndef __BOARD_H__
#define __BOARD_H__

extern void board_create_table();

#endif
