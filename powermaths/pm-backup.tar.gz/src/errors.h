#ifndef __ERROR_H__
#define __ERROR_H__

#include <gtk/gtk.h>

extern void error_dialog(char *message);

#endif
