#ifndef __ABOUT_H__
#define __ABOUT_H__

extern void about_show();

#endif
