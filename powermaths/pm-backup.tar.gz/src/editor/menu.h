#ifndef __MENU_H__
#define __MENU_H__

#include <gtk/gtk.h>

extern GtkWidget *menu_create();

#endif
