#ifndef __TOOLBAR_H__
#define __TOOLBAR_H__

#include <gtk/gtk.h>

extern GtkWidget *toolbar_create();

#endif
