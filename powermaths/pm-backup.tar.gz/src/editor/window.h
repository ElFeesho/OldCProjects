#ifndef __WINDOW_H__
#define __WINDOW_H__

extern void window_show();

#endif
