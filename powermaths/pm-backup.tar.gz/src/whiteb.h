#ifndef __WHITEB_H__
#define __WHITEB_H__

#include "question.h"

extern void whiteb_show(struct question *data);

#endif
