#ifndef __SPLASH_H__
#define __SPLASH_H__

extern void splash_show();

#endif
