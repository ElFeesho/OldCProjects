#include <gtk/gtk.h>
#include <stdio.h>
#include "database.h"
#include "browser.h"
#include "misc.h"
#include "globals.h"
#include "errors.h"
#include "levels.h"
#include "types.h"

/* Callback Declarations */
static void levels_button_click(GtkWidget *button, gpointer selected);
/* End of callbacks */

struct levels_node *levels_selected;
static struct levels_node *levels_list = NULL;

static int levels_count = 0;

int levels_load_list()
{
	if(levels_list!=NULL)
	{
		free(levels_list);
		levels_list = NULL;
	}

	sqlite3_stmt *levels = database_query(g_strdup_printf("SELECT * from Grades INNER JOIN Group_Grades ON Group_Grades.Grade_ID = Grades.Grade_ID WHERE Group_Grades.Group_ID = %d LIMIT 10",groups_selected->id));
	int count = 0;
	while(sqlite3_step(levels)==SQLITE_ROW)
	{
		if(levels_list == NULL)
		{
			levels_list = malloc(sizeof(struct levels_node));
			levels_list->id = sqlite3_column_int(levels,0);
			levels_list->name = g_strdup((char*)sqlite3_column_text(levels,1));
			levels_list->next = NULL;
		}
		else
		{
			struct levels_node *temp = malloc(sizeof(struct levels_node));
			temp->id = sqlite3_column_int(levels,0);
			temp->name = g_strdup((char*)sqlite3_column_text(levels,1));
			temp->next = levels_list;
			levels_list = temp;
		}
		count++;
	}
	levels_count = count;
	return count;	
}

void levels_create_table()
{
	if(!levels_load_list())
	{
		error_dialog("Failed loading grades!");
		exit(1);
	}
	if(!browser_table)
		browser_table = gtk_table_new(levels_count+5,8,1);
	else
		gtk_table_resize(GTK_TABLE(browser_table),levels_count+10,8);

	browser_change_label(misc_create_banner("Select a Level",50));
	
	gtk_table_attach_defaults(GTK_TABLE(browser_table),gtk_label_new("Which level you choose, reflects the difficulty of the questions."),0,8,1,2);
	
	GtkWidget *level[10];
	int i = 0;
	struct levels_node *temp = levels_list;
	for(i=0;i<levels_count && temp!=NULL;i++,temp=temp->next)
	{
		level[i] = gtk_button_new_with_label(temp->name);
		if(i<=4)
			gtk_table_attach(GTK_TABLE(browser_table),level[i],1,2,2+i*2,(2+i*2)+1,GTK_FILL,GTK_FILL,0,0);
		else
			gtk_table_attach(GTK_TABLE(browser_table),level[i],4,5,2+(i-5)*2,(2+(i-5)*2)+1,GTK_FILL,GTK_FILL,0,0);
		g_signal_connect(G_OBJECT(level[i]),"clicked",G_CALLBACK(levels_button_click),temp);
	}
	gtk_widget_show_all(browser_table);
	return;
}

void levels_button_click(GtkWidget *button, gpointer selected)
{
	levels_selected = selected;
	gtk_container_forall(GTK_CONTAINER(browser_table),(GtkCallback)gtk_widget_destroy,NULL);
	types_create_table();
	browser_add_history(gtk_button_new_with_label("Levels"),levels_create_table);
}
