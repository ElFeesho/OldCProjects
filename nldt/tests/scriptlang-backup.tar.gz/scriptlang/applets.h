#ifndef __LUA_VMS__
#define __LUA_VMS__

#include <lua.h>
#include <lauxlib.h>

typedef struct _nldt_applet_child_node
{
	GtkWidget *widget; /* Actual Widget */
	char *lua_name;	 /* Lua variable name */
}nldt_applet_child_node;

typedef struct _nldt_applet_node
{
   struct lua_State *L; /* Lua 'VM' */
	
	GtkWidget *applet_space;
	GtkWidget *canvas;
	GdkPixmap *canv_buffer;
	GdkGC *buff_gc;
	
	char *script_name;
	int has_focus;
	nldt_applet_child_node *children;
	void *next;
	int x;
	int y;
	int w;
	int h;
	GdkColor bg_col;
}nldt_applet_node;

extern void nldt_applet_load(char *script_name);
extern void nldt_applet_reset_focus();
extern void nldt_applet_update();
extern void nldt_applet_mouse_down(int x, int y);
extern void nldt_applet_mouse_move(int x, int y);
extern void nldt_applet_mouse_up(int x, int y);
extern void nldt_applet_key_down(int keyval);
extern void nldt_applet_key_up(int keyval);
extern void nldt_applet_shutdown();

extern nldt_applet_node *nldt_applet_lookup(struct lua_State *L);

#endif 
