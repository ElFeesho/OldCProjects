-- Nonlogic Desktop Skeleton Applet Script --

-- Underscores ('_') denote special variables

_x = 10.0
_y = 10.0
_width = 500.0
_height = 400.0
_bg_col = "#f90"
-- Some used objects

clear_button = nil
surprise = nil

-- Drawing Vars
oldx = 0.0
oldy = 0.0

canv_width = 0.0
canv_height = 0.0

function init(x, y, w, h, bg_col)
-- Set the x, y, width and height of the applet
-- if they are not 0 (!= == ~= in lua)
   if (x ~= 0) then
      _x = x
   end
   if (y ~= 0) then
      _y = y
   end
   if (w ~= 0) then
      _w = w
   end
   if (h ~= 0) then
      _h = h
   end
	if(bg_col~=nil) then
		_bg_col = bg_col
	end
-- Draw a header in a box
   draw.box_rel(12,12,_width-18,42,"#CCC","#CCC")
   draw.box_rel(10,10,_width-20,40,"#000","#08F")
	draw.text_rel(15,15,22,"#fff","<b>NLPad</b> - <i>Lite</i>")
	
-- Draw 'Toolbar'
	draw.box_rel(_width-45,15,30,30,"#000","#F00")
	draw.image_file("pixbufs/clear.png",_width-40,20)
-- Draw canvas
	canv_width = _width-40
	canv_height = _height-80
	draw.box_rel(23,63,_width-37,_height-77,"#CCC","#CCC")
	draw.box_rel(20,60,_width-40,_height-80,"#000","#FFF")

-- Add a clear button
	clear_button = gtk.button_new("Clear", 30, 30)
	gtk.set_position(clear_button,_width-45,15)
-- callback to "destroy" function can be made now even though
-- destroy hasn't been defined because the script is read through
-- once before init is launched.
	gtk.signal_connect(clear_button,"clicked","clear")
end

function on_expose()
-- Possible to put in expose events
end

function on_update()
-- I'm at a loss Mr. Bond, I have nothing to do
end

function on_mouse_down(mousex, mousey, button)
-- When the mouse clicks add something special here
	if(button == 3) then
	   if (surprise == nil) then
   	   surprise = gtk.label_new("surprise!")
	   else
	      gtk.label_set_text(surprise,"surprise!")
	      gtk.show(surprise)
	   end
	   gtk.set_position(surprise, mousex, mousey)
	elseif (button == 1) then
		oldx = mousex
		oldy = mousey
	end
end

function on_mouse_move(mousex, mousey, button)
-- Move the surprise label around the applet
	if(surprise ~= nil) then
	   gtk.set_position(surprise, mousex, mousey)
	end
	if(button == 1) then
		draw.clip_line_rel(20,60,canv_width,canv_height,oldx,oldy,mousex,mousey,3,"#000")
		oldx = mousex
		oldy = mousey
	end
end

function on_mouse_up(mousex, mousey, button)
-- Make the surpise label disappear
	if(surprise ~= nil) then
	   gtk.hide(surprise)
	end
-- MAGIC!
end

function on_key_press(keyval)
-- On a key press, show the surprise label 
-- at a different location with different
-- text
   if (surprise == nil) then
      surprise = gtk_label_new("Argh!")
   else
      gtk_label_set_text(surprise,"Argh!")
      gtk_show(surprise)
   end
   gtk_set_position(surprise,_width/2,_height/2)
end

function on_key_release(keyval)
--- Hide the surprise label again
   gtk_hide(surprise)
--- It's smoke n mirrors!
end

function clear()
-- Clear the canvas by just drawing a new one (fiendish isn't it)
	draw.box_rel(20,60,_width-40,_height-80,"#000","#FFF")
	
end

function destroy()
-- Save the last size of the applet
-- save_geometry()
-- Remove the applet from the run queue
-- close_applet()
	print("Destroying!!!\n");
end

