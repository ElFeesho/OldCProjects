-- Nonlogic Desktop Skeleton Applet Script --

-- Underscores ('_') denote special variables

_x = 10.0
_y = 10.0
_width = 300.0
_height = 400.0

-- Some used objects

close = nil
suprise = nil

function init(x, y, w, h)
-- Set the x, y, width and height of the applet
-- if they are not 0 (!= == ~= in lua)
   if (x ~= 0) then
      _x = x
   end
   if (y ~= 0) then
      _y = y
   end
   if (w ~= 0) then
      _w = w
   end
   if (h ~= 0) then
      _h = h
   end
-- Draw a header in a box
   draw_box_rel(10,10,_width-10,40,"#000","#08F")
   draw_text_rel(15,15,24,"#fff","NLDT Applet")
-- Draw a close button
   close = gtk_button("Close", 40, 30)
	gtk_set_position(button,_width-50,_height-40)
-- callback to "destroy" function can be made now even though
-- destroy hasn't been defined because the script is read through
-- once before init is launched.
   gtk_signal_connect(button,"clicked","destroy")
end

function on_update()
-- I'm at a loss Mr. Bond, I have nothing to do
end

function on_mouse_down(mousex, mousey)
-- When the mouse clicks add something special here
   if (suprise == nil) then
      suprise = gtk_label_new("Suprise!")
   else
      gtk_label_set_text(suprise,"Suprise!")
      gtk_show(suprise)
   end
   gtk_set_position(suprise, mousex, mousey)
end

function on_mouse_move(mousex, mousey)
-- Move the "suprise" label around the applet
   gtk_set_position(suprise, mousex, mousey)
end

function on_mouse_release(mousex, mousey)
-- Make the surpise label disappear
   gtk_hide(suprise)
-- MAGIC!
end

function on_key_press(keyval)
-- On a key press, show the suprise label 
-- at a different location with different
-- text
   if (suprise == nil) then
      suprise = gtk_label_new("Argh!")
   else
      gtk_label_set_text(suprise,"Argh!")
      gtk_show(suprise)
   end
   gtk_set_position(suprise,_width/2,_height/2)
end

function on_key_release(keyval)
--- Hide the suprise label again
   gtk_hide(suprise)
--- It's smoke n mirrors!
end

function destroy()
-- Save the last size of the applet
   save_geometry()
-- Remove the applet from the run queue
   close_applet()
end