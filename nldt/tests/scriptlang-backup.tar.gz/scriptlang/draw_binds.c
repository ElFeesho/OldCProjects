#include <gtk/gtk.h>
#include <lua.h>
#include <lauxlib.h>

#include "applets.h"

/* gtk_widget_* funcs */
extern int NLDT_draw_box_rel(struct lua_State *L)
{
	/*
		LUA Use:
			draw_box_rel(x, y, width, height, border-col, fill-col)
	*/
	if(lua_gettop(L)!=6)
	{
		lua_pushstring(L, "ERROR draw_box_rel usage: x, y, width, height, border-col, fill-col");
		lua_error(L);
	}
	int x, y, h, w;
	GdkColor border, fillcol;
	x = luaL_checkint(L,1);
	y = luaL_checkint(L,2);
	w = luaL_checkint(L,3);
	h = luaL_checkint(L,4);
	gdk_color_parse(lua_tostring(L,5),&border);
	gdk_color_parse(lua_tostring(L,6),&fillcol);
	nldt_applet_node *owner = nldt_applet_lookup(L);
	if(owner==NULL)
	{
		fprintf(stderr,"Failed to look up applet\n");
		return 0;
	}
	GdkGC *gc[2];
	gc[0] = gdk_gc_new(owner->canv_buffer);
	if(owner->canvas->window!=NULL)
	{
		gc[1] = gdk_gc_new(owner->canvas->window);
		gdk_gc_set_rgb_fg_color(gc[1],&fillcol);
		gdk_draw_rectangle(owner->canvas->window,gc[1],1,x,y,w,h);
		gdk_gc_set_rgb_fg_color(gc[1],&border);
		gdk_draw_rectangle(owner->canvas->window,gc[1],0,x,y,w-1,h-1);
	}
	gdk_gc_set_rgb_fg_color(gc[0],&fillcol);
	gdk_draw_rectangle(owner->canv_buffer,gc[0],1,x,y,w,h);
	gdk_gc_set_rgb_fg_color(gc[0],&border);
	gdk_draw_rectangle(owner->canv_buffer,gc[0],0,x,y,w-1,h-1);
	
	return 0;
}

extern int NLDT_draw_text_rel(struct lua_State *L)
{
	/*
		LUA Use:
			draw_text_rel(X,Y,Size,Colour,Text)
	*/
	if(lua_gettop(L)!=5)
	{
		lua_pushstring(L,"ERROR draw_text_rel usage X, Y, Size, Colour, Text");
		lua_error(L);
	}
	int x, y, size;
	x = luaL_checkint(L,1);
	y = luaL_checkint(L,2);
	size = luaL_checkint(L,3);
	GdkColor text_col;
	gdk_color_parse(lua_tostring(L,4),&text_col);
	int t_len = 0;
	char *text = (char*)luaL_checklstring(L,5,&t_len);
	PangoContext *pango_c = gdk_pango_context_get_for_screen (gdk_screen_get_default());
	PangoFontDescription *pdesc = pango_font_description_new();
	pango_font_description_set_family(pdesc,"arial");
	pango_font_description_set_size(pdesc,size*PANGO_SCALE);
	pango_context_set_font_description(pango_c,pdesc);
	PangoLayout *text_layout = pango_layout_new(pango_c);
	
	pango_layout_set_markup(text_layout,text,t_len);
	
	nldt_applet_node *owner = nldt_applet_lookup(L);
	if(owner==NULL)
	{
		fprintf(stderr,"Failed to look up applet\n");
		return 0;
	}
	gdk_gc_set_rgb_fg_color(owner->buff_gc,&text_col);
	gdk_draw_layout(owner->canv_buffer,owner->buff_gc,x,y,text_layout);
	if(owner->canvas->window!=NULL)
	{
		GdkGC *canv_gc = gdk_gc_new(owner->canvas->window);
		gdk_gc_set_rgb_fg_color(canv_gc,&text_col);
		gdk_draw_layout(owner->canvas->window,canv_gc,x,y,text_layout);
	}
	return 0;
}

extern int NLDT_draw_line_rel(struct lua_State *L)
{
	/*
		LUA Use:
			draw_box_rel(x, y, width, height, border-col, fill-col)
	*/
	if(lua_gettop(L)!=6)
	{
		lua_pushstring(L, "ERROR draw_line_rel usage: x, y, x2, y2, width, line-col");
		lua_error(L);
	}
	int x, y, x2, y2, width;
	GdkColor line_col;
	x = luaL_checkint(L,1);
	y = luaL_checkint(L,2);
	x2 = luaL_checkint(L,3);
	y2 = luaL_checkint(L,4);
	width = luaL_checkint(L,5);
	gdk_color_parse(lua_tostring(L,6),&line_col);

	nldt_applet_node *owner = nldt_applet_lookup(L);
	if(owner==NULL)
	{
		fprintf(stderr,"Failed to look up applet\n");
		return 0;
	}
	GdkGC *gc[2];
	gc[0] = gdk_gc_new(owner->canv_buffer);
	if(owner->canvas->window!=NULL)
	{
		gc[1] = gdk_gc_new(owner->canvas->window);
		gdk_gc_set_rgb_fg_color(gc[1],&line_col);
		gdk_gc_set_line_attributes(gc[1],width,GDK_LINE_SOLID,GDK_CAP_ROUND,GDK_JOIN_ROUND);
		gdk_draw_line(owner->canvas->window,gc[1],x,y,x2,y2);
	}
	gdk_gc_set_rgb_fg_color(gc[0],&line_col);
	gdk_gc_set_line_attributes(gc[0],width,GDK_LINE_SOLID,GDK_CAP_ROUND,GDK_JOIN_ROUND);
	gdk_draw_line(owner->canv_buffer,gc[0],x,y,x2,y2);

	return 0;
}

extern int NLDT_draw_clip_line_rel(struct lua_State *L)
{
	/*
		LUA Use:
			draw_clip_line_rel(clipx, clipy, clipw, cliph, x, y, width, height, border-col, fill-col)
	*/
	if(lua_gettop(L)!=10)
	{
		lua_pushstring(L, "ERROR draw_clip_line_rel usage: cx, cy, cw, ch, x, y, x2, y2, width, line-col");
		lua_error(L);
	}
	int cx, cy, cw, ch;
	
	int x, y, x2, y2, width;
	GdkColor line_col;
	cx = luaL_checkint(L,1);
	cy = luaL_checkint(L,2);
	cw = luaL_checkint(L,3);
	ch = luaL_checkint(L,4);
	
	x = luaL_checkint(L,5);
	y = luaL_checkint(L,6);
	x2 = luaL_checkint(L,7);
	y2 = luaL_checkint(L,8);
	width = luaL_checkint(L,9);
	gdk_color_parse(lua_tostring(L,10),&line_col);

	nldt_applet_node *owner = nldt_applet_lookup(L);
	if(owner==NULL)
	{
		fprintf(stderr,"Failed to look up applet\n");
		return 0;
	}
	GdkGC *gc[2];
	gc[0] = gdk_gc_new(owner->canv_buffer);
	
	GdkRectangle clip_rect = { cx, cy, cw, ch };
	
	gdk_gc_set_clip_rectangle(gc[0],&clip_rect);
	if(owner->canvas->window!=NULL)
	{
		gc[1] = gdk_gc_new(owner->canvas->window);
		gdk_gc_set_clip_rectangle(gc[1],&clip_rect);
		gdk_gc_set_rgb_fg_color(gc[1],&line_col);
		gdk_gc_set_line_attributes(gc[1],width,GDK_LINE_SOLID,GDK_CAP_ROUND,GDK_JOIN_ROUND);
		gdk_draw_line(owner->canvas->window,gc[1],x,y,x2,y2);
	}
	gdk_gc_set_rgb_fg_color(gc[0],&line_col);
	gdk_gc_set_line_attributes(gc[0],width,GDK_LINE_SOLID,GDK_CAP_ROUND,GDK_JOIN_ROUND);
	gdk_draw_line(owner->canv_buffer,gc[0],x,y,x2,y2);

	return 0;
}

extern int NLDT_draw_image_file(struct lua_State *L)
{
	/*
		LUA Use:
			draw_image_file(imagefile, x, y)
	*/
	if(lua_gettop(L)!=3)
	{
		lua_pushstring(L, "ERROR draw_image_file usage: \"filename\", x, y\n");
		lua_error(L);
	}
	char *image_name = (char*)lua_tostring(L,1);
	int x, y;
	x = luaL_checkint(L,2);
	y = luaL_checkint(L,3);
	GdkPixbuf *image = gdk_pixbuf_new_from_file(image_name,NULL);
	if(image == NULL)
	{
		lua_pushfstring(L,"ERROR Image not found: %s\n",image_name);
		lua_error(L);
	}
	
	nldt_applet_node *owner = nldt_applet_lookup(L);
	if(owner==NULL)
	{
		fprintf(stderr,"Failed to look up applet\n");
		return 0;
	}
	
	GdkGC *gc[2];
	gc[0] = gdk_gc_new(owner->canv_buffer);
	
	if(owner->canvas->window!=NULL)
	{
		gc[1] = gdk_gc_new(owner->canvas->window);
		gdk_draw_pixbuf(owner->canvas->window,gc[1],image,0,0,x,y,-1,-1,GDK_RGB_DITHER_NONE,0,0);
	}
	gdk_draw_pixbuf(owner->canv_buffer,gc[0],image,0,0,x,y,-1,-1,GDK_RGB_DITHER_NONE,0,0);
	
	return 0;
}


const luaL_reg nldt_draw_methods[] =
{
	{ "box_rel", NLDT_draw_box_rel },
	{ "text_rel", NLDT_draw_text_rel },
	{ "line_rel", NLDT_draw_line_rel },
	{ "clip_line_rel", NLDT_draw_clip_line_rel },
	{ "image_file", NLDT_draw_image_file },
	{ 0, 0 }
};

