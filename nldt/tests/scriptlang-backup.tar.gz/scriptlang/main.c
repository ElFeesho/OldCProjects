#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <stdlib.h>
#include <lua.h>
#include <lauxlib.h>

#include "gtk_binds.h"
#include "applets.h"

static GtkWidget *fixed = NULL;

extern void main_window_add_child(GtkWidget *child, int x, int y)
{
	gtk_fixed_put(GTK_FIXED(fixed),child, x, y);
	gtk_widget_show_all(child);
}

static gboolean window_close(GtkWidget *window, gpointer user_data)
{
	nldt_applet_shutdown();
	gtk_exit(0);
	return FALSE;
}

static gboolean update_applets(gpointer user_data)
{
	nldt_applet_update();
	return TRUE;
}

int main(int argc, char **argv)
{
	g_set_application_name("NLDT: Script Test");

	/*
		gtk_init merely handles the arguements passed
		to the program so you can change some gtk
		specific functions before our app gets to 
		read any arguements we may want to parse
	*/
	gtk_init(&argc, &argv);
	
	GtkWidget *window;
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window,600,500);
	
	fixed = gtk_fixed_new();
	
	gtk_container_add(GTK_CONTAINER(window),fixed);
	
	/*
		gtk_main is where we say good bye to our program
		flow and watch as it leaves home to become a man
	*/
	g_signal_connect(G_OBJECT(window),"delete-event",G_CALLBACK(window_close),NULL);
	gtk_widget_show_all(window);
	nldt_applet_load("scripttest.lua");
	printf("Loaded script\n");
	g_timeout_add(40,(GSourceFunc)update_applets,NULL);
	
	gtk_main();
	return 0;
}
