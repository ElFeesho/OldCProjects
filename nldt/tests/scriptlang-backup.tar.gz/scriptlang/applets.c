#include <gtk/gtk.h>
#include <lua.h>
#include <lauxlib.h>

#include "applets.h"
#include "gtk_binds.h"
#include "draw_binds.h"

extern void main_window_add_child(GtkWidget *child, int x, int y);

static nldt_applet_node *nldt_applet_list = NULL;

static gboolean nldt_applet_canvas_expose(GtkWidget *canvas, GdkEventExpose *ev, gpointer user_data)
{
	nldt_applet_node *temp = (nldt_applet_node*)user_data;
	lua_getglobal(temp->L,"on_expose");
	int result = lua_pcall(temp->L,0,0,0);
	if(result)
	{
		fprintf(stderr,"Failed to run expose function on %s script\nError: %s\n",temp->script_name,lua_tostring(temp->L,-1));
	}
	gdk_draw_drawable(canvas->window, gdk_gc_new(canvas->window), temp->canv_buffer,0,0,0,0,temp->w,temp->h);
	gdk_draw_rectangle(canvas->window, gdk_gc_new(canvas->window), 0,0,0,temp->w-1,temp->h-1);
	return TRUE;
}

static gboolean nldt_applet_canvas_mouse_down(GtkWidget *canvas, GdkEventButton *ev, gpointer user_data)
{
	nldt_applet_reset_focus();
	nldt_applet_node *temp = (nldt_applet_node*)user_data;
	temp->has_focus = TRUE;
	lua_getglobal(temp->L,"on_mouse_down");
	lua_pushinteger(temp->L,ev->x);
	lua_pushinteger(temp->L,ev->y);
	lua_pushinteger(temp->L,ev->button);
	int result = lua_pcall(temp->L,3,0,0);
	if(result)
	{
		fprintf(stderr,"Failed to run on_mouse_down function on %s script\nError: %s\n",temp->script_name,lua_tostring(temp->L,-1));
	}
	return TRUE; //Don't allow any other mouse click's to be capture by other signals
}

static gboolean nldt_applet_canvas_mouse_move(GtkWidget *canvas, GdkEventMotion *ev, gpointer user_data)
{
	nldt_applet_reset_focus();
	nldt_applet_node *temp = (nldt_applet_node*)user_data;
	temp->has_focus = TRUE;
	lua_getglobal(temp->L,"on_mouse_move");
	lua_pushinteger(temp->L,ev->x);
	lua_pushinteger(temp->L,ev->y);
	int button = 0;
	if((ev->state & GDK_BUTTON1_MASK) == GDK_BUTTON1_MASK)
	{
		button = 1;
	}
	else if((ev->state & GDK_BUTTON2_MASK) == GDK_BUTTON2_MASK)
	{
		button = 2;
	}
	else if((ev->state & GDK_BUTTON3_MASK) == GDK_BUTTON3_MASK)
	{
		button = 3;
	}
	lua_pushinteger(temp->L,button);
	int result = lua_pcall(temp->L,3,0,0);
	if(result)
	{
		fprintf(stderr,"Failed to run on_mouse_move function on %s script\nError: %s\n",temp->script_name,lua_tostring(temp->L,-1));
	}
	return TRUE; //Don't allow any other mouse click's to be capture by other signals
}

static gboolean nldt_applet_canvas_mouse_up(GtkWidget *canvas, GdkEventButton *ev, gpointer user_data)
{
	nldt_applet_reset_focus();
	nldt_applet_node *temp = (nldt_applet_node*)user_data;
	temp->has_focus = TRUE;
	lua_getglobal(temp->L,"on_mouse_up");
	lua_pushinteger(temp->L,ev->x);
	lua_pushinteger(temp->L,ev->y);
	lua_pushinteger(temp->L,ev->button);
	int result = lua_pcall(temp->L,3,0,0);
	if(result)
	{
		fprintf(stderr,"Failed to run on_mouse_up function on %s script\n\nError: %s\n",temp->script_name,lua_tostring(temp->L,-1));
	}
	return TRUE; //Don't allow any other mouse click's to be capture by other signals
}

extern void nldt_applet_load(char *script_name)
{
	if(!nldt_applet_list)
	{
		nldt_applet_list = g_new(nldt_applet_node, 1);
		nldt_applet_list->applet_space = gtk_layout_new();
		nldt_applet_list->canvas = gtk_drawing_area_new();
		gtk_fixed_put(GTK_FIXED(nldt_applet_list->applet_space),nldt_applet_list->canvas,0,0);
		nldt_applet_list->L = lua_open();
		nldt_applet_list->children = NULL;
		nldt_applet_list->next = NULL;
		nldt_applet_list->has_focus = TRUE;
		nldt_applet_list->script_name = g_strdup(script_name);
		
		luaL_openlibs(nldt_applet_list->L);
		
		luaL_register(nldt_applet_list->L,"gtk",nldt_gtk_methods);
		luaL_register(nldt_applet_list->L,"draw",nldt_draw_methods);		
		
		int file_stat = luaL_loadfile(nldt_applet_list->L, script_name);
		if(file_stat)
		{
			fprintf(stderr,"Failed loading %s applet\n", script_name);
			fprintf(stderr,"Clearing up\n");
			lua_close(nldt_applet_list->L);
			nldt_applet_list = NULL;
			return;
		}
		
		int result = lua_pcall(nldt_applet_list->L, 0, 0, 0);
		if(result)
		{
			fprintf(stderr,"Failed to run %s\n",script_name);
			fprintf(stderr,"Clearing up\n");
			lua_close(nldt_applet_list->L);
			nldt_applet_list = NULL;
			return;
		}

		lua_getglobal(nldt_applet_list->L,"_x");
		lua_getglobal(nldt_applet_list->L,"_y");
		lua_getglobal(nldt_applet_list->L,"_width");
		lua_getglobal(nldt_applet_list->L,"_height");
		lua_getglobal(nldt_applet_list->L,"_bg_col");
		
		//Feesh! What are you doing!!! THe script hasn't been inited!
		//These values won't be correct!
		
		//Well they will, because I'll add a check to make sure there
		// is no previous geometry before making the backing pixmap
		nldt_applet_list->x = lua_tointeger(nldt_applet_list->L,-5);
		nldt_applet_list->y = lua_tointeger(nldt_applet_list->L,-4);
		nldt_applet_list->w = lua_tointeger(nldt_applet_list->L,-3);
		nldt_applet_list->h = lua_tointeger(nldt_applet_list->L,-2);
		gdk_color_parse(lua_tostring(nldt_applet_list->L,-1),&nldt_applet_list->bg_col);
				
		nldt_applet_list->canv_buffer = gdk_pixmap_new(NULL,nldt_applet_list->w, nldt_applet_list->h, 24);
		nldt_applet_list->buff_gc = gdk_gc_new(nldt_applet_list->canv_buffer);
		
		gdk_gc_set_rgb_fg_color(nldt_applet_list->buff_gc,&nldt_applet_list->bg_col);
		
		gdk_draw_rectangle(nldt_applet_list->canv_buffer,nldt_applet_list->buff_gc,1,0,0,nldt_applet_list->w,nldt_applet_list->h);
		
		lua_getglobal(nldt_applet_list->L,"init");
		lua_pushinteger(nldt_applet_list->L,0);
		lua_pushinteger(nldt_applet_list->L,0);
		lua_pushinteger(nldt_applet_list->L,0);
		lua_pushinteger(nldt_applet_list->L,0);
		lua_pushstring(nldt_applet_list->L,NULL);
		
		result = lua_pcall(nldt_applet_list->L,5,0,0);
		
		if(result)
		{
			fprintf(stderr,"Failed initialising %s\n",script_name);
			fprintf(stderr,"Clearing up\n");
			fprintf(stderr,"Lua Error: %s\n",lua_tostring(nldt_applet_list->L,-1));
			lua_close(nldt_applet_list->L);
			nldt_applet_list = NULL;
			return;
		}
		
		lua_getglobal(nldt_applet_list->L,"_x");
		lua_getglobal(nldt_applet_list->L,"_y");
		lua_getglobal(nldt_applet_list->L,"_width");
		lua_getglobal(nldt_applet_list->L,"_height");
		lua_getglobal(nldt_applet_list->L,"_bg_col");
		
		//After init function, x, y, width and height should be set so
		//store em in the applet struct
		nldt_applet_list->x = lua_tointeger(nldt_applet_list->L,-5);
		nldt_applet_list->y = lua_tointeger(nldt_applet_list->L,-4);
		nldt_applet_list->w = lua_tointeger(nldt_applet_list->L,-3);
		nldt_applet_list->h = lua_tointeger(nldt_applet_list->L,-2);
		gdk_color_parse(lua_tostring(nldt_applet_list->L,-1),&nldt_applet_list->bg_col);
		printf("Applet Dims: %d %d %d %d\n",nldt_applet_list->x, nldt_applet_list->y, nldt_applet_list->w, nldt_applet_list->h);
		
		gtk_widget_set_size_request(nldt_applet_list->applet_space,nldt_applet_list->w,nldt_applet_list->h);
		gtk_widget_set_size_request(nldt_applet_list->canvas,nldt_applet_list->w,nldt_applet_list->h);
				
		gtk_widget_add_events(nldt_applet_list->canvas,GDK_POINTER_MOTION_MASK|GDK_BUTTON1_MOTION_MASK|GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK);
		g_signal_connect(G_OBJECT(nldt_applet_list->canvas),"expose-event",G_CALLBACK(nldt_applet_canvas_expose),nldt_applet_list);
		g_signal_connect(G_OBJECT(nldt_applet_list->canvas),"button-press-event",G_CALLBACK(nldt_applet_canvas_mouse_down),nldt_applet_list);
		g_signal_connect(G_OBJECT(nldt_applet_list->canvas),"button-release-event",G_CALLBACK(nldt_applet_canvas_mouse_up),nldt_applet_list);
		g_signal_connect(G_OBJECT(nldt_applet_list->canvas),"motion-notify-event",G_CALLBACK(nldt_applet_canvas_mouse_move),nldt_applet_list);
		main_window_add_child(nldt_applet_list->applet_space,nldt_applet_list->x, nldt_applet_list->y);
	}
}

extern void nldt_applet_reset_focus()
{
	nldt_applet_node *temp = nldt_applet_list;
	while(temp!=NULL)
	{
		temp->has_focus = FALSE;
		temp = temp->next;
	}
}

extern void nldt_applet_update()
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		lua_getglobal(temp->L,"on_update");
		result = lua_pcall(temp->L,0,0,0);
		if(result)
		{
			fprintf(stderr,"Failed to run update function on %s script\n",temp->script_name);
		}
		temp = temp->next;		
	}
}

extern void nldt_applet_mouse_down(int x, int y)
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		lua_getglobal(temp->L,"on_mouse_down");
		lua_pushinteger(temp->L,x);
		lua_pushinteger(temp->L,y);
		result = lua_pcall(temp->L,2,0,0);
		if(result)
		{
			fprintf(stderr,"Failed to run mouse down function on %s script\n",temp->script_name);
		}
		temp = temp->next;		
	}	
}

extern void nldt_applet_mouse_move(int x, int y)
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		lua_getglobal(temp->L,"on_mouse_move");
		lua_pushinteger(temp->L,x);
		lua_pushinteger(temp->L,y);
		result = lua_pcall(temp->L,2,0,0);
		if(result)
		{
			fprintf(stderr,"Failed to run mouse move function on %s script\n",temp->script_name);
		}
		temp = temp->next;		
	}
}

extern void nldt_applet_mouse_up(int x, int y)
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		lua_getglobal(temp->L,"on_mouse_up");
		lua_pushinteger(temp->L,x);
		lua_pushinteger(temp->L,y);
		result = lua_pcall(temp->L,2,0,0);
		if(result)
		{
			fprintf(stderr,"Failed to run update function on %s script\n",temp->script_name);
		}
		temp = temp->next;
	}
}

extern void nldt_applet_key_down(int keyval)
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		if(temp->has_focus)
		{
			lua_getglobal(temp->L,"on_key_down");
			lua_pushinteger(temp->L,keyval);
			result = lua_pcall(temp->L,1,0,0);
			if(result)
			{
				fprintf(stderr,"Failed to run key down function on %s script\n",temp->script_name);
			}		
		}
		temp = temp->next;
	}
}

extern void nldt_applet_key_up(int keyval)
{
	nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		if(temp->has_focus)
		{
			lua_getglobal(temp->L,"on_key_up");
			lua_pushinteger(temp->L,keyval);
			result = lua_pcall(temp->L,1,0,0);
			if(result)
			{
				fprintf(stderr,"Failed to run key up function on %s script\n",temp->script_name);
			}
		}
		temp = temp->next;
	}
}

extern void nldt_applet_shutdown()
{
nldt_applet_node *temp = nldt_applet_list;
	int result = 0;
	while(temp!=NULL)
	{
		lua_close(temp->L);
		temp = temp->next;
	}
}

extern nldt_applet_node *nldt_applet_lookup(struct lua_State *L)
{
	nldt_applet_node *temp = nldt_applet_list;
	while(temp!=NULL)
	{
		if(temp->L == L)
			return temp;
		temp = temp->next;
	}
	return NULL;
}
