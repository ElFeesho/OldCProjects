#ifndef __DESKTOP_H__
#define __DESKTOP_H__

extern void desktop_show();

#endif
